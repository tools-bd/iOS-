package com.island.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private lateinit var status: TextView
    private var land = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val sp = Prefs.sp(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        col.addView(TextView(this).apply { text = "Island"; textSize = 32f; typeface = Typeface.DEFAULT_BOLD })
        status = TextView(this).apply { textSize = 15f; setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Enable Island (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(TextView(this).apply {
            text = "Android 13+: if it's greyed out, go to App info > ⋮ > Allow restricted settings, then try again."
            textSize = 12f
        })

        col.addView(TextView(this).apply {
            text = if (land) "Editing: LANDSCAPE settings" else "Editing: PORTRAIT settings"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(20), 0, 0)
        })
        col.addView(TextView(this).apply {
            text = "Phone ke ghurale onno orientation er settings edit hobe. Island rotate korle nijei oi settings use korbe."
            textSize = 12f
        })

        col.addView(section("Normal (collapsed) island"))
        slider(col, "Width (dp)", Prefs.W, 40, 400)
        slider(col, "Height (dp)", Prefs.H, 20, 120)
        slider(col, "Up / Down (dp)", Prefs.Y, 0, 300)
        slider(col, "Left / Right (dp)", Prefs.X, -400, 400)
        slider(col, "Corner radius (dp)", Prefs.R, 0, 60)

        col.addView(section("When active (expanded)"))
        slider(col, "Active width (dp)", Prefs.EW, 100, 600)
        slider(col, "Active height (dp)", Prefs.EH, 30, 200)
        slider(col, "Extra move down when active (dp)", Prefs.EY, 0, 100)

        col.addView(section("Color"))
        val row = LinearLayout(this)
        listOf(
            "Black" to 0xFF000000.toInt(), "Graphite" to 0xFF2C2C2E.toInt(),
            "Navy" to 0xFF0A2540.toInt(), "Red" to 0xFFB00020.toInt(), "White" to 0xFFFFFFFF.toInt()
        ).forEach { (n, c) ->
            row.addView(Button(this).apply {
                text = n; textSize = 10f
                setOnClickListener { sp.edit().putInt(Prefs.COLOR, c).apply() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        col.addView(row)

        col.addView(Switch(this).apply {
            text = "Expand on notifications"
            isChecked = sp.getBoolean(Prefs.PEEK, true)
            setPadding(0, dp(16), 0, dp(8))
            setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(Prefs.PEEK, v).apply() }
        })
        col.addView(Button(this).apply {
            text = "Test expand"
            setOnClickListener { sp.edit().putLong(Prefs.TEST, System.currentTimeMillis()).apply() }
        })
        col.addView(Button(this).apply {
            text = if (land) "Reset landscape settings" else "Reset portrait settings"
            setOnClickListener {
                val e = sp.edit()
                Prefs.DEFAULTS.keys.forEach { e.remove(Prefs.key(it, land)) }
                e.apply()
                recreate()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun section(t: String) = TextView(this).apply {
        text = t; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(24), 0, 0)
    }

    private fun slider(parent: LinearLayout, title: String, name: String, min: Int, max: Int) {
        val sp = Prefs.sp(this)
        val key = Prefs.key(name, land)
        val cur = Prefs.get(this, name, land)
        val tv = TextView(this).apply { text = "$title: $cur"; textSize = 16f; setPadding(0, dp(16), 0, 0) }
        val sb = SeekBar(this).apply { this.max = max - min; progress = (cur - min).coerceIn(0, max - min) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$title: $v"
                if (fromUser) sp.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    override fun onResume() {
        super.onResume()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        status.text = if (s.contains("$packageName/")) "Status: ON ✅" else "Status: OFF ❌ (enable it below)"
    }
}
