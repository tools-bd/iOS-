package com.island.app

import android.content.Context

object Prefs {
    // size / position keys (each has a portrait and a landscape copy)
    const val W = "w"; const val H = "h"; const val X = "x"; const val Y = "y"; const val R = "r"
    // when active (expanded)
    const val EW = "ew"; const val EH = "eh"; const val EY = "ey"
    // shared
    const val COLOR = "color"; const val PEEK = "peek"; const val TEST = "test"

    val DEFAULTS = mapOf(
        W to 120, H to 34, X to 0, Y to 10, R to 17,
        EW to 300, EH to 70, EY to 6
    )

    fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun key(name: String, land: Boolean) = if (land) "l_$name" else name
    fun get(c: Context, name: String, land: Boolean): Int =
        sp(c).getInt(key(name, land), DEFAULTS[name] ?: 0)
}
