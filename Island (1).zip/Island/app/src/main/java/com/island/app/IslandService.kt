package com.island.app

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var wm: WindowManager
    private lateinit var island: FrameLayout
    private lateinit var label: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private val bg = GradientDrawable()
    private val handler = Handler(Looper.getMainLooper())
    private val collapse = Runnable { setExpanded(false) }
    private var expanded = false
    private var added = false
    private var land = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun v(name: String) = Prefs.get(this, name, land)
    private fun clock() = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (added) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(dp(14), 0, dp(14), 0)
            visibility = View.GONE
        }
        island = FrameLayout(this).apply {
            background = bg
            addView(label, FrameLayout.LayoutParams(-1, -1))
            setOnClickListener { setExpanded(!expanded, clock()) }
        }
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        lp = WindowManager.LayoutParams(
            dp(120), dp(34),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }

        applyPrefs()
        wm.addView(island, lp)
        added = true
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this)
    }

    /** Phone rotated: switch to the portrait or landscape settings. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!added) return
        land = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        resetToCollapsed()
    }

    private fun resetToCollapsed() {
        handler.removeCallbacks(collapse)
        expanded = false
        label.animate().cancel()
        label.visibility = View.GONE
        applyPrefs()
        // The system re-lays out after rotation, so apply once more shortly after.
        handler.postDelayed({ if (added && !expanded) applyPrefs() }, 300)
    }

    private fun applyPrefs() {
        val sp = Prefs.sp(this)
        lp.width = dp(v(Prefs.W))
        lp.height = dp(v(Prefs.H))
        lp.x = dp(v(Prefs.X))
        lp.y = dp(v(Prefs.Y))
        bg.setColor(sp.getInt(Prefs.COLOR, Color.BLACK))
        bg.cornerRadius = dp(v(Prefs.R)).toFloat()
        if (added) wm.updateViewLayout(island, lp)
    }

    private fun setExpanded(on: Boolean, text: String? = null) {
        handler.removeCallbacks(collapse)
        val baseW = dp(v(Prefs.W))
        val baseH = dp(v(Prefs.H)).coerceAtLeast(1)
        val baseY = dp(v(Prefs.Y))
        val baseR = dp(v(Prefs.R)).toFloat()
        val maxW = resources.displayMetrics.widthPixels - dp(16)
        val toW = if (on) minOf(dp(v(Prefs.EW)), maxW).coerceAtLeast(baseW) else baseW
        val toH = if (on) dp(v(Prefs.EH)).coerceAtLeast(baseH) else baseH
        val toY = if (on) baseY + dp(v(Prefs.EY)) else baseY
        val fromW = lp.width
        val fromH = lp.height
        val fromY = lp.y
        expanded = on

        label.animate().cancel()
        if (on) {
            label.text = text ?: clock()
            label.alpha = 0f
            label.visibility = View.VISIBLE
            label.animate().alpha(1f).setStartDelay(120).setDuration(200).start()
        } else {
            label.visibility = View.GONE
        }

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            interpolator = OvershootInterpolator(1.0f)
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.width = (fromW + (toW - fromW) * f).toInt().coerceAtLeast(1)
                lp.height = (fromH + (toH - fromH) * f).toInt().coerceAtLeast(1)
                lp.y = (fromY + (toY - fromY) * f).toInt()
                bg.cornerRadius = minOf(baseR * lp.height / baseH, lp.height / 2f)
                if (added) wm.updateViewLayout(island, lp)
            }
            start()
        }
        if (on) handler.postDelayed(collapse, 4000)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == Prefs.TEST) { setExpanded(true, "Hello from Island"); return }
        resetToCollapsed()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        if (!Prefs.sp(this).getBoolean(Prefs.PEEK, true)) return
        if (e.packageName == packageName) return
        val txt = e.text.joinToString(" ").trim()
        if (txt.isNotEmpty()) setExpanded(true, txt)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this)
        if (added) { try { wm.removeView(island) } catch (_: Exception) {}; added = false }
        super.onDestroy()
    }
}
